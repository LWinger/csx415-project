# Deploying the Trained Models on New Data

## Model objects (stored as data) in package ‘NASApredictor’:

basic_classtree_model             
basic_linear_model                
basic_logistic_model              
basic_regtree_model               
tuned_rf_class_model              
tuned_rf_reg_model                
tuned_xgb_class_model             
tuned_xgb_reg_model   


## Sample data in package ‘NASApredictor’:

test_sample                       
train_sample  